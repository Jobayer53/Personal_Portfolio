# personal-portfolio

Live Preview : https://nirjonx.github.io/personal-portfolio/

Assets

Unicons: https://iconscout.com/unicons

Boxicons: https://boxicons.com/

Fonts: https://fonts.google.com/

Swiper: https://swiperjs.com/

HSL color:https://www.w3schools.com/colors/colors_hsl.asp
